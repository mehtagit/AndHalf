package com.gl.ceir.config.service;

import com.gl.ceir.config.model.MobileOperator;

public interface MobileOperatorService extends RestServices<MobileOperator> {

}
