package com.gl.ceir.config.service;

import com.gl.ceir.config.model.ImsieSeries;

public interface ImsieSeriesService extends RestServices<ImsieSeries> {

}
