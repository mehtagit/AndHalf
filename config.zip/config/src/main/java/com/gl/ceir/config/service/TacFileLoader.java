package com.gl.ceir.config.service;

public interface TacFileLoader extends Runnable {
	public Boolean upload();
}
