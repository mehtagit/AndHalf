package com.gl.ceir.config.Mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StackHolderMapper {

	
	
	
	
}
