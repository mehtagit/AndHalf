package com.gl.ceir.config.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.ceir.config.model.Rules;

public interface RulesRepository extends JpaRepository<Rules, Long> {

}
