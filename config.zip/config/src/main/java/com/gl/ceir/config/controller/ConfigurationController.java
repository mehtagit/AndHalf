package com.gl.ceir.config.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConfigurationController {







}
