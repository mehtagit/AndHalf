package com.gl.ceir.config.service;

import com.gl.ceir.config.model.Rules;

public interface RulesService extends RestServices<Rules> {

}
