package com.gl.ceir.config.model.constants;

public enum MessageType {
	NOTIFICATION, REMINDER, INFO;
}
