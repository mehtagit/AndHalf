package com.gl.ceir.config.model;

public class UserProfile {

}
