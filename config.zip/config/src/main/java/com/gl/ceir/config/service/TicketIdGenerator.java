package com.gl.ceir.config.service;

public interface TicketIdGenerator {

	public String getTicketId();
}
