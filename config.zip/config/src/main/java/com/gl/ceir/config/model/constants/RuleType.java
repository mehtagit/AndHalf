package com.gl.ceir.config.model.constants;

public enum RuleType {
	STATIC, EXCEPTION, DYNAMIC;

}
