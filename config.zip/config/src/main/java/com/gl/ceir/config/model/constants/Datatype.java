package com.gl.ceir.config.model.constants;

public enum Datatype {
INT,STRING,BOOLEAN,DATE;
}
