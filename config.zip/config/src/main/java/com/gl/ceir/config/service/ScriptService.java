package com.gl.ceir.config.service;

import com.gl.ceir.config.model.Script;

public interface ScriptService extends RestServices<Script> {

}
