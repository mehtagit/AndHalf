package com.gl.ceir.config.service;

import com.gl.ceir.config.model.MediationSource;

public interface MediationSourceService extends RestServices<MediationSource> {

}
