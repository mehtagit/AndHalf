package com.gl.ceir.config.model.constants;

public enum RulesNames {
	NULL, LENGTH, VIP, ALREADY_REGULISED, PENDING_REGULISED, DUPLICATE, TAX_PAID, LUHN_ALGO, TAC;
}
