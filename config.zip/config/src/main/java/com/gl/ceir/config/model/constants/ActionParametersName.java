package com.gl.ceir.config.model.constants;

public enum ActionParametersName {
	MESSAGE_ID, WAITING_TIME, IS_BLOCK, IS_ALLOW, IS_GREY_LIST, USER_REGULARISATION_TIME_LIMIT;
}
