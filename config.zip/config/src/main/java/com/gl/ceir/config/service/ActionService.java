package com.gl.ceir.config.service;

import com.gl.ceir.config.model.Action;

public interface ActionService extends RestServices<Action> {

}
