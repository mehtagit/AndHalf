package com.gl.ceir.config.model;

public class ImeiInfo {

	private Long firstImei;
	private Long firstMsisdn;
	private Long secondImei;
	private Long secondMsidn;
	private String status;
	public Long getFirstImei() {
		return firstImei;
	}
	public void setFirstImei(Long firstImei) {
		this.firstImei = firstImei;
	}
	public Long getFirstMsisdn() {
		return firstMsisdn;
	}
	public void setFirstMsisdn(Long firstMsisdn) {
		this.firstMsisdn = firstMsisdn;
	}
	public Long getSecondImei() {
		return secondImei;
	}
	public void setSecondImei(Long secondImei) {
		this.secondImei = secondImei;
	}
	public Long getSecondMsidn() {
		return secondMsidn;
	}
	public void setSecondMsidn(Long secondMsidn) {
		this.secondMsidn = secondMsidn;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
}
