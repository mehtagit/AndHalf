package com.functionapps.parser;


//import com.gl.Rule_engine.RuleEngineApplication;


public class RuleTesting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		RuleEngineApplication re = new RuleEngineApplication();
//		String output = "";
	
		
//		RuleEngineApplication.main("LBD","1",
//				"IMEI",
//				"DeviceID",
//				"FILE Name",
//				"Oprator ID",
//				"RecordID",
//				"Operator Name",
//				"Error",
//				"Operator Type",
//				"Period",
//				"msisdn");
		
	}

}
