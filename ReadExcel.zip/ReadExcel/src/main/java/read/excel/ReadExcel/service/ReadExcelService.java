package read.excel.ReadExcel.service;

public interface ReadExcelService {

	public boolean existsByProvinceAndDistrict(String province,String District);
}
