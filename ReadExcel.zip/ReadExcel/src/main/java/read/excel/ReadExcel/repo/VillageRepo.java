package read.excel.ReadExcel.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import read.excel.ReadExcel.entity.Village;

public interface VillageRepo extends JpaRepository<Village, Long>{
}
