package read.excel.ReadExcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadExcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
